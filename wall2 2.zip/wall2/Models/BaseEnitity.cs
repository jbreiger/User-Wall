namespace wall2.Models {
    public abstract class BaseEntity {
        
    }
}