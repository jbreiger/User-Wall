// using wall2.Models;
// using System.Collections.Generic;

// namespace wall2.Repository {
//     public interface IRepository<T> where T : BaseEntity {
//         void Add(T item);
//         T FindByID(int id);
//         IEnumerable<T> FindAll(); 
//     }
// }