using wall2.Models;
using System.Collections.Generic;

namespace wall2.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {

    }
}